<!DOCTYPE HTML>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Equinox Research | Services </title>
    <link rel="shortcut icon" href="<?php echo e(asset('dist/img/favicon.png')); ?>" type="image/x-icon">

    <!-- CSS here -->
    <?php echo $__env->make('live.include.top_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body data-spy="scroll" data-offset="70">
<!-- Preloader -->
<?php echo $__env->make('live.include.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header -->
<?php echo $__env->make('live.include.top_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header end-->


<main>

    <!-- job feature start -->
    <section class="breadcrumb-area">
        <div class="breadcrumb-widget  pt-145 pb-200" style="background-image: url('<?php echo e(asset('dist/img/breadcrumb/bg-2.png')); ?>');">
            <div class="container">
                <div class="row pb-100 pb-sm-0">
                    <div class="col-md-12">
                        <div class="breadcrumb-content pt-140 pb-15">
                            <h1>Equinox Research | Services</h1>
                            <ul>
                                <li><a href="<?php echo e(route('live.index')); ?>l">home</a></li>
                                <li><a href="<?php echo e(route('live.pages.services')); ?>">Services</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- job feature end -->

    <?php echo $__env->make('live.include.services-new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('live.include.package-new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</main>

<!-- footer -->
<?php echo $__env->make('live.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- footer end -->

<!-- Back to top button -->
<a id="back-to-top" title="Back to Top"></a>

<!-- JS here -->
<?php echo $__env->make('live.include.bottom_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH E:\Development\Web-Development\xampp\htdocs\equinoxresearch\resources\views/live/pages/services.blade.php ENDPATH**/ ?>