<!DOCTYPE HTML>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Equinox Research | About US </title>
    <link rel="shortcut icon" href="<?php echo e(asset('dist/img/favicon.png')); ?>" type="image/x-icon">

    <!-- CSS here -->
    <?php echo $__env->make('live.include.top_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
<!-- Preloader -->
<?php echo $__env->make('live.include.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header -->
<?php echo $__env->make('live.include.top_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header end-->


<main>
    <!-- Banner start -->
    <section class="banner-area-2 pt-145" style="background-image: url('<?php echo e(asset('dist/img/banner/about-bg.png')); ?>');">
        <div class="container">
            <div class="row align-items-center pt-130 pb-140">
                <div class="col-xl-6 col-lg-8">
                    <div class="banner-content py-5">
                        <div class="section-title text-start">
                            <span class="short-title wow fadeInUp">ABOUT US</span>

                            <h1 class="wow fadeInUp mb-0" data-wow-delay='0.2s' style="color: white">Believing, banking
                                and achieving
                                different</h1>
                        </div>
                        <a class="theme-btn-2 theme-btn-primary mt-45 wow fadeInUp" data-wow-delay="0.4s" href="<?php echo e(route('live.pages.services')); ?>"
                           style="color: white">
                                <span class="arrow">
                                    <span class="horizontal-line"></span>
                                </span>View our Services
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Banner end -->

    <section class="bg_white pt-90 pb-40 ">
        <div class="container">
            <div class="description-widget">
                <div class="row">
                    <div class="col-md-4">
                        <div class="desc-title text-end bg_primary">
                            <h2>A journey that started with a belief to Do Different</h2>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="desc-text pl-lg-10">
                            <p class="mt-35">Pankaj Ramanuj Randad is an Indian-born Entrepreneur and Stocks Analyst &
                                Consultant. He is the founder of Equinox Research and Advisors, Pune – a consulting firm
                                offering a multitude of quality services to its clients in the areas of Stocks, Futures
                                & Options, Equity and more. Before founding Equinox, Pankaj worked in prominent roles in
                                eminent organizations including Motilal Oswal, PhillipCapital, and IndiaNivesh. He has
                                gained immense exposure to technical analysis of stocks while working on hundreds of
                                them over a career spanning 15+ years.</p>

                            <p class="mt-20">Pankaj is a post graduate in Marketing Management and is a SEBIregistered
                                Research Analyst (registration number – INH000008288). Coming from a Maheshwari business
                                family in Latur, Maharashtra, he is fluent in Hindi, English, Marathi, Marwadi and
                                Gujarati and is based in Pune, India. His interests and passions lie in varied
                                sports/games including Chess (where he was an inter-university Table-A player),
                                Swimming, Snooker and Cricket.</p>

                            <p class="mt-20">Of the things he has accomplished during his career, Pankaj particularly liked Futures &
                                options and gravitated toward it more and more. Over the years, he has gained extensive
                                expertise in this area. Today, as the Founder of Equinox, Pankaj is helping UHNIs, HNIs
                                and corporates in the areas of:</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistics start -->
    <section class="statistics-area pt-135 pb-140 bg_white">
        <div class="container">
            <div class="row pt-30 pb-30 gy-4 gy-lg-0">
                <div class="col-lg-6 ">
                    <div class="statistics-widget-2 wow fadeInRight" data-wow-delay="0.7s">
                        <div class="widget-content widget-6"
                             style="background-image: url('<?php echo e(asset('dist/img/statistics/img-2.png')); ?>')">
                            <h2>Futures and Options </h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 ">
                    <div class="statistics-widget-2 wow fadeInRight" data-wow-delay="0.7s">
                        <div class="widget-content widget-6"
                             style="background-image: url('<?php echo e(asset('dist/img/statistics/img-2.png')); ?>')">
                            <h2>Futures and Options </h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row gy-4 gy-md-0">
                <div class="col-md-6">
                    <div class="statistics-widget-2 wow fadeInLeft" data-wow-delay="0.1s">
                        <div class="widget-content widget-7"
                             style="background-image: url('<?php echo e(asset('dist/img/statistics/img-3.png')); ?>');">
                            <h1 class="stat-counter">Equity</h1>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="statistics-widget-2 wow fadeInLeft" data-wow-delay="0.1s">
                        <div class="widget-content widget-7"
                             style="background-image: url('<?php echo e(asset('dist/img/statistics/img-3.png')); ?>');">
                            <h1 class="stat-counter">Commodities</h1>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- Statistics end -->

    <!-- Recgnition start -->
    
    <!-- Recgnition end -->

    <!-- Leadership Team start -->
    <section class="leadership-area pt-135 pb-140 bg_disable">
        <div class="container">
            <div class="row align-items-end">
                <div class="col-sm-8">
                    <div class="section-title text-start wow fadeInRight">
                        <span class="short-title mt-0">Leadership</span>

                        <h2 class="mb-0">Meet our leadership team</h2>
                    </div>
                </div>
            </div>

            <div class="row pt-65 gy-md-0 gy-4">
                <div class="col-lg-6">
                    <div class="single-leadership-widget wow fadeInUp " data-wow-delay="0.1s">
                        <a href="#">
                            <img src="<?php echo e(asset('dist/img/leadership/img-1.png')); ?>" alt="leader-1">

                            <div class="leader-info">
                                <h5>Atul Ausekar</h5>

                                <p>Designation: Channel Partner</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="single-leadership-widget wow fadeInUp " data-wow-delay="0.3s">
                        <a href="#">
                            <img src="<?php echo e(asset('dist/img/leadership/img-2.png')); ?>" alt="leader-2">

                            <div class="leader-info">
                                <h5>Pankaj Randa</h5>

                                <p>Founder and CEO (EQUINOX RESEARCH AND ADVISORY) </p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Leadership Team end -->

    <!-- Call To Action start -->
    <section class="cta-area-2 pt-80 pb-80">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="cta-content text-black wow fadeInRight">
                        <h2>Our latest results</h2>

                        <p>Access Equinox Research’s latest quarterly results and other financial documents.</p>
                    </div>
                </div>
                <div class="col-md-6 ">
                    <div class="cta-content mt-3 mt-sm-0 text-sm-end text-center">
                        <a href="#" class="theme-btn wow fadeInLeft">See results</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Call To Action end -->
</main>

<!-- footer -->

<?php echo $__env->make('live.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- footer end -->

<!-- Back to top button -->
<a id="back-to-top" title="Back to Top"></a>

<!-- JS here -->
<?php echo $__env->make('live.include.bottom_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH E:\Development\Web-Development\xampp\htdocs\equinoxresearch\resources\views/live/pages/about_us.blade.php ENDPATH**/ ?>