<div id="preloader">
    <div id="ctn-preloader" class="ctn-preloader">
        <div class="round_spinner">
            <div class="spinner"></div>
            <div class="text">
                <img src="<?php echo e(asset('dist/img/logo/Logo-2.png')); ?>" alt="">
            </div>
        </div>
        <h2 class="head">Did You Know?</h2>
        <p></p>
    </div>
</div><?php /**PATH E:\Development\Web-Development\xampp\htdocs\equinoxresearch\resources\views/live/include/preloader.blade.php ENDPATH**/ ?>