<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/bootstrap.min.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/elegant-icons.min.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/all.min.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/animate.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/slick.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/slick-theme.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/nice-select.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/animate.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/jquery.fancybox.min.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/nouislider.min.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/default.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/style.css')); ?>" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/responsive.css')); ?>" media="all" /><?php /**PATH E:\Development\Web-Development\xampp\htdocs\equinoxresearch\resources\views/live/include/top_scripts.blade.php ENDPATH**/ ?>