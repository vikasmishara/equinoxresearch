<script type="text/javascript" src="<?php echo e(asset('dist/js/jquery-3.6.0.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/preloader.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/jquery.smoothscroll.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/jquery.nice-select.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/jquery.fancybox.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/slick.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/nouislider.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/wNumb.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/parallax.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/jquery.parallax-scroll.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/wow.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/custom.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('dist/js/jquery.counterup.min.js')); ?>"></script><?php /**PATH E:\Development\Web-Development\xampp\htdocs\equinoxresearch\resources\views/live/include/bottom_scripts.blade.php ENDPATH**/ ?>