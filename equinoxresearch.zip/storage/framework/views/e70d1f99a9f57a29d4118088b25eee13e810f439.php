<!DOCTYPE HTML>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Equinox Research | Home </title>
    <link rel="shortcut icon" href="<?php echo e(asset('dist/img/favicon.png')); ?>" type="image/x-icon">

    <!-- CSS here -->
 <?php echo $__env->make('live.include.top_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body data-spy="scroll" data-offset="70">
<!-- Preloader -->
<?php echo $__env->make('live.include.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header -->
<?php echo $__env->make('live.include.top_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header end-->


<main>

    <!-- banner section -->
<?php echo $__env->make('live.include.slider.home_slider_banner_two', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- banner section end-->

    <!-- marketplace logo section start-->
    
    <!-- marketplace logo section end-->

    <?php echo $__env->make('live.include.services-new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('live.include.package-new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('live.include.testimonials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    



</main>

<!-- footer -->
<?php echo $__env->make('live.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- footer end -->

<!-- Back to top button -->
<a id="back-to-top" title="Back to Top"></a>

<!-- JS here -->
<?php echo $__env->make('live.include.bottom_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH E:\Development\Web-Development\xampp\htdocs\equinoxresearch\resources\views/live/index.blade.php ENDPATH**/ ?>